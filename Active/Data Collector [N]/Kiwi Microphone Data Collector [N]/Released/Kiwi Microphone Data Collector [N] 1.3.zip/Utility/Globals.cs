﻿namespace Samraksh.AppNote.Utility {
	/// <summary>
	/// Global stuff
	/// </summary>
	public static class Globals {
		/// <summary>
		/// Global LCD
		/// </summary>
		public static readonly EnhancedEmoteLcd EnhancedLcd = new EnhancedEmoteLcd();
	}
}
