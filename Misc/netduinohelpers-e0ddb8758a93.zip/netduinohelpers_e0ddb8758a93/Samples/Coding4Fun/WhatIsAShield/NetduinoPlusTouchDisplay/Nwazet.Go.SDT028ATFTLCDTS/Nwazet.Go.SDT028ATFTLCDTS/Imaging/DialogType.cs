namespace Nwazet.Go.Imaging {
    public enum DialogType {
        Alphanumeric
    }
}