namespace Nwazet.Go.Imaging {
    public enum CornerPosition {
        TopLeft,
        TopRight,
        BottomLeft,
        BottomRight
    }
}