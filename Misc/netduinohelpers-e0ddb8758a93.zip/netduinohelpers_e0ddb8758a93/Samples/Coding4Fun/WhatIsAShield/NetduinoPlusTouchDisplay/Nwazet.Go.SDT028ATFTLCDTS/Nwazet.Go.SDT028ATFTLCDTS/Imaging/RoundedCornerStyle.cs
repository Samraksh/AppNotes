namespace Nwazet.Go.Imaging {
    public enum RoundedCornerStyle {
        None,
        All,
        Top,
        Bottom,
        Left,
        Right
    }
}