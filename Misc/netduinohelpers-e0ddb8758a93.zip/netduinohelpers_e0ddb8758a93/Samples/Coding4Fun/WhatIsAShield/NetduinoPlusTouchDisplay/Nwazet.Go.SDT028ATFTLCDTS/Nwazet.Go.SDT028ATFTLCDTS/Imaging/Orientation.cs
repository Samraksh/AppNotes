namespace Nwazet.Go.Imaging {
    public enum Orientation {
        Portrait,
        Landscape
    }
}