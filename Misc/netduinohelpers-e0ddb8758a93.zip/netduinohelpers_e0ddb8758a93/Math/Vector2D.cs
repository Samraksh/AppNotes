namespace netduino.helpers.Math {
    public class Vector2D {
        public float X { get; set; }
        public float Y { get; set; }
    }
}
