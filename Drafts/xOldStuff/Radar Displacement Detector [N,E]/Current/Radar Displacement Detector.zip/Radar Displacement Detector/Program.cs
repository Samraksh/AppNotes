/*--------------------------------------------------------------------
 * Radar Displacement Detector: app note for the eMote .NOW
 * (c) 2013 The Samraksh Company
 * 
 * Version history
 *      1.0: initial release
 *      1.1: Removed check for background noise
 *      
---------------------------------------------------------------------*/

using System;
using System.Reflection;
using System.Threading;
using Microsoft.SPOT;

using Samraksh.AppNote.Utility;

using Samraksh.eMote.DotNow;
//using AnalogInput = Samraksh.eMote.DotNow.AnalogInput;

namespace Samraksh.AppNote.DotNow.RadarDisplacementDetector {
    /// <summary>
    /// Displacement detection parameters
    /// </summary>
    public struct DetectorParameters {
        /// <summary>Number of milliseconds between samples</summary>
        public const int SamplingIntervalMilliSec = 4000;    // Larger values => fewer samples/sec
        /// <summary>Number of samples to collect before presenting for processing</summary>
        public const int BufferSize = 500;
        /// <summary>Number of samples per second</summary>
        public const int SamplesPerSecond = 1000000 / SamplingIntervalMilliSec;
        /// <summary>Number of microseconds between invocation of buffer processing callback</summary>
        public const int CallbackIntervalMs = (BufferSize * 1000) / SamplesPerSecond;
        /// <summary>Number of minor displacement events that must occur for displacement detection</summary>
        public const int M = 2;
        /// <summary>Number of seconds for which a displacement detection can last</summary>
        public const int N = 8;
        /// <summary>Minimum number of cuts (phase unwraps) that must occur for a minor displacement event</summary>
        //public const int MinCumCuts = 4;
        public const int MinCumCuts = 6;
        /// <summary>The centimeters traversed by one cut. This is a fixed characteristic of the Bumblebee; do not change this value.</summary>
        public const float CutDistanceCm = 5.2f;
    }


    /// <summary>
    /// Radar Displacement Detector
    ///     Detects displacement (towards or away from the radar)
    ///     Filters out "back and forth" movement (such as trees blowing in the wind)
    /// </summary>
    public static class RadarDisplacementDetector {

        private static readonly ushort[] Ibuffer = new ushort[DetectorParameters.BufferSize];
        private static readonly ushort[] Qbuffer = new ushort[DetectorParameters.BufferSize];

        private static readonly EmoteLcdUtil Lcd = new EmoteLcdUtil();

        /// <summary>
        /// Get things started
        /// </summary>
        public static void Main() {
            // Basic setup
            Debug.EnableGCMessages(false);

            VersionInfo.Init(Assembly.GetExecutingAssembly());
            Debug.Print("Radar Motion Detection " + VersionInfo.Version + " (" + VersionInfo.BuildDateTime + ")");
            Lcd.Display("radar");

            Thread.Sleep(4000); // Wait a bit before launch
            Debug.Print("Collecting initial data for mean");

            // Initialize radar fields
            //SampleData.InitNoise();
            CumulativeCuts.Initialize();

            AnalogInput.InitializeADC();
            AnalogInput.ConfigureContinuousModeDualChannel(Ibuffer, Qbuffer, (uint)Ibuffer.Length, DetectorParameters.SamplingIntervalMilliSec, AdcBuffer_Callback);

            MofNFilter.Initialize();

            //SD.Initialize();

            var processSampleBufferThread = new Thread(ProcessSampleBuffer);
            processSampleBufferThread.Start();

            Thread.Sleep(Timeout.Infinite);
        }


        private static int _currentlyProcessingBuffer = IntBool.False;
        private static int _callbackCtr;
        static readonly AutoResetEvent ProcessSampleBufferAutoResetEvent = new AutoResetEvent(false);

        /// <summary>
        /// Callback for buffered ADC
        /// </summary>
        /// <param name="threshold"></param>
        private static void AdcBuffer_Callback(long threshold) {

            _callbackCtr++;

            Debug.Print("Blocked " + _currentlyProcessingBuffer);

            // Check if we're currently processing a buffer. If so, give message and return
            //  The variable is reset in ProcessSampleBuffer.
            if (Interlocked.CompareExchange(ref _currentlyProcessingBuffer, IntBool.True, IntBool.False) == IntBool.True) {
                Debug.Print(
                    "***************************************************************** Missed a buffer; callback #" + _callbackCtr);
                return;
            }

            // Not currently processing a buffer. Signal processing and return.

            //Debug.Print("b. blocked " + _currentlyProcessingBuffer);

            ProcessSampleBufferAutoResetEvent.Set();
        }


        static int totalTimeMs;
        /// <summary>
        /// Process the sample buffer in a separate thread
        /// </summary>
        private static void ProcessSampleBuffer() {
            while (true) {
                // Wait for callback to signal that a buffer is ready for processing
                ProcessSampleBufferAutoResetEvent.WaitOne();
                var callbackCtr = _callbackCtr; // avoid race condition
                var started = DateTime.Now;
                Debug.Print("Started  " + started.Minute + ":" + started.Second + "." + started.Millisecond);

                for (var i = 0; i < DetectorParameters.BufferSize; i++) {
                    SampleData.CurrSample.I = Ibuffer[i];
                    SampleData.CurrSample.Q = Qbuffer[i];
                    ProcessSample();
                }

                var finished = DateTime.Now;
                var timeSpan = finished - started;
                var timeMs = timeSpan.Seconds * 1000 + timeSpan.Milliseconds;
                totalTimeMs += timeMs;
                Debug.Print("Callback #" + callbackCtr + ", time " + timeMs + ", mean time " + (totalTimeMs / callbackCtr) + ", max time allowed " + DetectorParameters.CallbackIntervalMs);
                //                Debug.Print("Finished " + finished.Minute + ":" + finished.Second + "." + finished.Millisecond);
                Debug.Print("");

                // Indicate that we've finished processing the buffer
                _currentlyProcessingBuffer = IntBool.False;
            }
        }

        static bool _waitingForMean = true;
        //static readonly bool IsLittleEndian = Microsoft.SPOT.Hardware.Utility.ExtractValueFromArray(new byte[] { 0xaa, 0xbb }, 0, 2) == 0xbbaa;
        private static int _sampNum;
        //static readonly byte[] SampleBytes = new byte[4];
        /// <summary>
        /// Process a sample
        /// </summary>
        private static void ProcessSample() {
            //const int samplesToWait = (int)DetectorParameters.SamplesPerSecond * 10; // Wait for 10 seconds

            //SampleData.SampNum += 1;
            //GpioPorts.SampleProcessed.Write(SampleData.SampNum % 2 == 0);
            //Lcd.Display(SampleData.SampNum);

            //// Collect background noise data
            //if (SampleData.SampNum < samplesToWait) {
            //    SampleData.NoiseSum.I += SampleData.CurrSample.I;
            //    SampleData.NoiseSum.Q += SampleData.CurrSample.Q;
            //    return;
            //}

            //// Done collecting background noise data: calculate means and let user begin to move
            //if (SampleData.SampNum == samplesToWait) {
            //    SampleData.Mean.I = SampleData.NoiseSum.I / samplesToWait;
            //    SampleData.Mean.Q = SampleData.NoiseSum.Q / samplesToWait;
            //    Debug.Print("*** Start moving");
            //}

            //// Adjust sample data by the noise mean and update cumulative cuts
            //SampleData.CompSample.I = SampleData.CurrSample.I - SampleData.Mean.I;
            //SampleData.CompSample.Q = SampleData.CurrSample.Q - SampleData.Mean.Q;
            //CumulativeCuts.Update(SampleData.CompSample);

            //Debug.Print("# " + SampleData.CurrSample.I + ", " + SampleData.CurrSample.Q);

            //// Store sample
            //if (IsLittleEndian) {
            //    SampleBytes[1] = (byte)(SampleData.CurrSample.I >> 8);
            //    SampleBytes[0] = (byte)(SampleData.CurrSample.I & 255);
            //    SampleBytes[3] = (byte)(SampleData.CurrSample.Q >> 8);
            //    SampleBytes[2] = (byte)(SampleData.CurrSample.Q & 255);

            //}
            //else {
            //    SampleBytes[0] = (byte)(SampleData.CurrSample.I >> 8);
            //    SampleBytes[1] = (byte)(SampleData.CurrSample.I & 255);
            //    SampleBytes[2] = (byte)(SampleData.CurrSample.Q >> 8);
            //    SampleBytes[3] = (byte)(SampleData.CurrSample.Q & 255);
            //}
            //SD.Write(SampleBytes, 0, (ushort)SampleBytes.Length);

            _sampNum++;

            // Update mean
            SampleMean.AddSample(SampleData.CurrSample);

            // If we haven't yet filled the buffer, return
            if (!SampleMean.Filled) {
                //Debug.Print("$ "+ SampleData.CurrSample.I + ", " + SampleData.CurrSample.Q);
                return;
            }

            if (_waitingForMean) {
                _waitingForMean = false;
                Debug.Print("Finished with initial mean; now processing data");
            }

            // Get the current mean of the samples
            var sampleMean = SampleMean.Mean;

            // Adjust current sample by the mean and check for a cut
            Sample compSample;
            compSample.I = SampleData.CurrSample.I - sampleMean.I;
            compSample.Q = SampleData.CurrSample.Q - sampleMean.Q;
            CumulativeCuts.Update(compSample);

            // Update snippet counter and see if we've reached a snippet boundary (one second)
            MofNFilter.SnippetCntr++;
            if (MofNFilter.SnippetCntr != DetectorParameters.SamplesPerSecond) {
                return;
            }

            //Debug.Print("Snippet cntr " + MofNFilter.SnippetCntr + ", samples/sec " + DetectorParameters.SamplesPerSecond + ", samp num " + _sampNum);

            // We've collected cumulative cut data for a snippet. See if displacement has occurred
            //  Displacement occurs only if there are more than MinCumCuts in the snippet
            var displacementDetected = (System.Math.Abs(CumulativeCuts.CumCuts) >= DetectorParameters.MinCumCuts);

            // See if we've had displacement in N of the last M snippets
            MofNFilter.UpdateDetectionState(MofNFilter.SnippetNum, displacementDetected);

            // Reset M of N and cumulative cuts values
            MofNFilter.SnippetNum++;
            MofNFilter.SnippetCntr = 0;
            CumulativeCuts.Reset();

            // Displacement event started
            if (MofNFilter.Prevstate == DisplacementState.Inactive && MofNFilter.CurrState == DisplacementState.Displacing) {
                GpioPorts.DetectEvent.Write(true);
                Debug.Print("\n-------------------------Detect Event started");
            }

            // Displacement event ended
            else if (MofNFilter.Prevstate == DisplacementState.Displacing && MofNFilter.CurrState == DisplacementState.Inactive) {
                GpioPorts.DetectEvent.Write(false);
                Debug.Print("\n-------------------------Detect Event ended");
            }
        }

        /// <summary>
        /// Calculate cumulative cuts
        /// </summary>
        /// <remarks>One cut = 5.2 cm distance</remarks>
        public static class CumulativeCuts {
            private static Sample _prevSample;
            /// <summary>Cumulative cuts</summary>
            public static int CumCuts;

            /// <summary>
            /// Constructor: Initialize previous values
            /// </summary>
            public static void Initialize() {
                _prevSample.I = _prevSample.Q = 0;
            }

            /// <summary>
            /// Reset the cumulative cuts
            /// </summary>
            public static void Reset() {
                CumCuts = 0;
            }

            /// <summary>
            /// Increment or decrement the cumulative cuts based on previous and current sample
            /// </summary>
            /// <param name="currSample"></param>
            public static void Update(Sample currSample) {
                var direction = _prevSample.I * currSample.Q - currSample.I * _prevSample.Q;

                //Debug.Print("# " + direction + "; (" + currSample.Q + "," + _prevSample.Q + "); (" + currSample.I + "," + _prevSample.I + ")");

                if (direction < 0 && _prevSample.Q < 0 && currSample.Q > 0) {
                    CumCuts += 1;
                    //Debug.Print("\n+= " + CumCuts + "\n");
                }
                else if (direction > 0 && _prevSample.Q > 0 && currSample.Q < 0) {
                    CumCuts -= 1;
                    //Debug.Print("\n-= " + CumCuts + "\n");
                }

                _prevSample.I = currSample.I;
                _prevSample.Q = currSample.Q;
            }
        }

        /// <summary>
        /// Check if, in the last N seconds, there were M seconds in which events were detected.
        /// </summary>
        /// <remarks>
        /// Buff is a circular buffer of size M. 
        ///     It is initialized to values guaranteed to be sufficiently distant in the past so as to not trigger a detection event.
        /// UpdateDetectionState is called once per snippet (once per second). 
        ///     It checks to see if the current buffer value is sufficiently recent or not and sets the detection state accordingly.
        /// If displacement occurred during this snippet, 
        ///     then the snippet number is saved and the buffer pointer advances.
        /// When we do a comparison in UpdateDetectionState, the current buffer entry is the oldest snippet where displacement occurred.
        ///     Since all the other snippets are more recent, it suffices to see if the current one occurred within N snippets.
        /// </remarks>
        public static class MofNFilter {
            /// <summary>Counts samples to see when a snippet (one second) has been reached</summary>
            public static int SnippetCntr = 0;
            /// <summary>Snippet Number. Incremented once per second.</summary>
            public static int SnippetNum = 0;

            private const int M = DetectorParameters.M;  // Syntactic sugar
            private const int N = DetectorParameters.N;

            private static readonly int[] Buff = new int[M];
            private static int _currBuffPtr;

            /// <summary>Current state</summary>
            public static DisplacementState CurrState = DisplacementState.Inactive;

            /// <summary>Previous state</summary>
            public static DisplacementState Prevstate = DisplacementState.Inactive;

            /// <summary>
            /// Initialize M of N filter
            /// </summary>
            public static void Initialize() {
                for (var i = 0; i < Buff.Length; i++)
                    Buff[i] = -N;   // Any value less than -N will do
            }

            /// <summary>
            /// Determine whether we are detecting motion or not
            /// </summary>
            /// <param name="snippetNumber">Snippet Number</param>
            /// <param name="displacement">true iff displacement detection has occurred</param>
            public static void UpdateDetectionState(int snippetNumber, bool displacement) {

                //if (Prevstate != CurrState) { Debug.Print("States " + Prevstate + CurrState); }

                // Save the current state so we can check if there's been a change
                Prevstate = CurrState;

                // Check if the snippet number occurred sufficiently recently
                CurrState = (snippetNumber - Buff[_currBuffPtr] < N) ? DisplacementState.Displacing : DisplacementState.Inactive;

                //Debug.Print("MofN: curr snippet " + snippetNumber + ", curr buff val " + Buff[_currBuffPtr] + ", disp state " + CurrState);

                // If displacement occurred, record the current snippet number and advance the current buffer location
                if (!displacement) {
                    return;
                }
                Debug.Print("** displacement cuts " + CumulativeCuts.CumCuts + ", distance " + (CumulativeCuts.CumCuts * DetectorParameters.CutDistanceCm));
                Buff[_currBuffPtr] = snippetNumber;
                _currBuffPtr = (_currBuffPtr + 1) % M;
            }
        }


    }
}