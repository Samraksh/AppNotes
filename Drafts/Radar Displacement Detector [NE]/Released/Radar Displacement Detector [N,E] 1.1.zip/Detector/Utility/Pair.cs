using System;
using Microsoft.SPOT;

namespace Samraksh.Appnote.Utility {
    /// <summary>
    /// Pair of Integers
    /// </summary>
    public class PairInt {
        /// <summary>First value</summary>
        public int First;

        /// <summary>Second value</summary>
        public int Second;
    }
}
