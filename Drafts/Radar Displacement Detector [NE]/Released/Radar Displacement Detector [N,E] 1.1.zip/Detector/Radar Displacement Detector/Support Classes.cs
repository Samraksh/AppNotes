namespace Samraksh.AppNote.DotNow.RadarDisplacementDetector {

    /// <summary>
    /// Bool surrogate that can be passed as ref
    /// </summary>
    static class IntBool {
        public const int True = 1;
        public const int False = 0;
    }

}